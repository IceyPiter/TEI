package com.example.estados;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.github.chrisbanes.photoview.PhotoView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PhotoView goiais = (PhotoView) findViewById(R.id.GO);
        goiais.setImageResource(R.drawable.goiais);
        goiais.setVisibility(View.INVISIBLE);
        PhotoView matoG = (PhotoView) findViewById(R.id.MT);
        matoG.setImageResource(R.drawable.matog);
        matoG.setVisibility(View.INVISIBLE);
        PhotoView matoGS = (PhotoView) findViewById(R.id.MS);
        matoGS.setImageResource(R.drawable.matogs);
        matoGS.setVisibility(View.INVISIBLE);
        PhotoView distritoF = (PhotoView) findViewById(R.id.DF);
        distritoF.setImageResource(R.drawable.df);
        distritoF.setVisibility(View.INVISIBLE);
    }
    public void estadoPesquisa() {

        EditText inputEstado = (EditText) findViewById(R.id.estado);
        String idh_go = null, idh_df = null, idh_ms = null, idh_mt = null;
        String tam_go = null, tam_df = null, tam_ms = null, tam_mt = null;
        String pop_go = null, pop_df = null, pop_ms = null, pop_mt = null;


    }
}