package com.example.recyclerview.model;

public class Compromisso {
    private String NomeCompromisso;
    private String Local;
    private String Hora;

    public Compromisso(){

    }

    public Compromisso(String NomeCompromisso, String Local, String Hora) {
        this.NomeCompromisso = NomeCompromisso;
        this.Local = Local;
        this.Hora = Hora;
    }

    public String getNomeCompromisso() {
        return NomeCompromisso;
    }

    public void setNomeCompromisso(String NomeCompromisso) {
        this.NomeCompromisso = NomeCompromisso;
    }

    public String getLocal() {
        return Local;
    }

    public void setLocal(String Local) {
        this.Local = Local;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String Hora) {
        this.Hora = Hora;
    }
}
