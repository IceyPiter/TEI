package com.example.recyclerview.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recyclerview.R;
import com.example.recyclerview.model.Compromisso;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {

    private List<Compromisso> listaFilmes;

    public Adapter(List<Compromisso> lista){
        this.listaFilmes = lista;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itenLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_lista, parent, false) ;

        return new MyViewHolder(itenLista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Compromisso filme = listaFilmes.get(position);
        holder.nome.setText(filme.getNomeCompromisso());
        holder.local.setText(filme.getLocal());
        holder.hora.setText(filme.getHora());
        holder.data.setText(filme.getData());
    }

    @Override
    public int getItemCount() {
        return listaFilmes.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nome;
        TextView local;
        TextView hora;
        TextView data;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nome = itemView.findViewById(R.id.textNome);
            data = itemView.findViewById(R.id.textData);
            local = itemView.findViewById(R.id.textLocal);
            hora = itemView.findViewById(R.id.textHorario);
        }
    }

}
