package com.example.aulaalertdialog;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void AbrirDailog(View view){
        // Instanciar Dialog

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);

        // Configurar Título e mensagem

        dialog.setTitle("A calvice não é problema");
        dialog.setMessage("Você é calvo???");

        // Configurar cancelamento do AlertDialog

        dialog.setCancelable(false);

        // Configurar Ícone
        dialog.setIcon(android.R.drawable.btn_star_big_on);

        // Configurar ações para SIM e NÃO

        dialog.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(
                        getApplicationContext(),
                        "Sempre soube que você era calvo",
                        Toast.LENGTH_LONG
                ).show();
            }
        });

        dialog.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(
                        getApplicationContext(),
                        "Você é calvo, só não aceita",
                        Toast.LENGTH_LONG
                ).show();
            }
        });

        // Abrir e exibir AlertDialog

        dialog.create();
        dialog.show();
    }
}