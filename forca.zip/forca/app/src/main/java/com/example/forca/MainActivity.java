package com.example.forca;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        palavras = getResources().getStringArray(R.array.palavras);
    }
    String palavra;
    String palavras[];
    Integer teste = 1;
    char palavraEsc[];
    char palavraAt[];
    int posicao = 0;
    int vidas = 5;

    public void forca(View view) {
        Button iniciar = findViewById(R.id.button3);
        TextView letreiro = findViewById(R.id.textView12);
        TextView situacao1 = findViewById(R.id.situacao);
        EditText letra1 = findViewById(R.id.letra);
        TextView palavra1 = findViewById(R.id.palavra);
        TextView letras_erradas1 = findViewById(R.id.letras_erradas);
        String letras_erradas = letras_erradas1.getText().toString();
        String letra = letra1.getText().toString().toUpperCase();
        TextView vidas1 = findViewById(R.id.Vidas);
        char letra2 = letra.charAt(0);
        int abc = 0;

        if (teste == 1){
            String inicie = "Por favor inicie o jogo";
            abrirToast(inicie);
        }else{
            if (vidas != 0) {
                for (Character c : palavra.toCharArray()) {
                    if (letra2 == c) {
                        palavraAt[posicao] = letra2;
                    }
                    else{
                        abc += 1;
                    }
                    posicao += 1;
                }
                posicao = 0;

                if (abc == palavraEsc.length) {
                    letras_erradas1.setText(letras_erradas + letra.toUpperCase() + " ");
                    System.out.println(abc);
                    String erro = "A letra " + letra.toUpperCase() + " Está errada!!";
                    abrirToast(erro);
                    vidas1.setText("Você tem: " + (vidas -= 1) + " Vidas restantes");
                } else {
                    String acerto = "A letra " + letra + " Está correta";
                    abrirToast(acerto);
                }
                String resp = new String(palavraAt);
                palavra1.setText(resp);

                if(resp.equals(palavra)){
                    letras_erradas1.setVisibility(View.INVISIBLE);
                    palavra1.setVisibility(View.INVISIBLE);
                    letreiro.setVisibility(View.INVISIBLE);
                    situacao1.setVisibility(View.VISIBLE);
                    situacao1.setText("Você GANHOU!!!!");
                    teste = 1;
                    iniciar.setText("REINICIAR");
                    letras_erradas1.setText("");
                }
                if (vidas == 0){
                    letras_erradas1.setVisibility(View.INVISIBLE);
                    palavra1.setVisibility(View.INVISIBLE);
                    letreiro.setVisibility(View.INVISIBLE);
                    situacao1.setVisibility(View.VISIBLE);
                    situacao1.setText("Você perdeu :d");
                    teste = 1;
                    iniciar.setText("REINICIAR");
                    letras_erradas1.setText("");
                }
            }
        }

    }
    public void iniciar(View View){
        Button iniciar = findViewById(R.id.button3);
        TextView vidas1 = findViewById(R.id.Vidas);
        TextView situacao1 = findViewById(R.id.situacao);
        TextView letreiro = findViewById(R.id.textView12);
        TextView letras_erradas1 = findViewById(R.id.letras_erradas);
        TextView palavra1 = findViewById(R.id.palavra);
        Random escolha = new Random();
        int esc = escolha.nextInt(palavras.length);
        palavra = palavras[esc];
        palavraEsc = new char[palavra.length()];
        palavraAt = new char[palavra.length()];
        if (teste == 1) {
            for (int i = 0; i < palavra.length(); i++) {
                palavraEsc[i] = palavra.charAt(i);
                palavraAt[i] = '*';
                String resp = new String(palavraAt);
                palavra1.setText(resp);
            }
        }
        teste+=1;
        String inicio = "Jogo iniciado";
        abrirToast(inicio);
        situacao1.setVisibility(View.INVISIBLE);
        letras_erradas1.setVisibility(View.VISIBLE);
        palavra1.setVisibility(View.VISIBLE);
        letreiro.setVisibility(View.VISIBLE);
        vidas1.setText("Você tem: 5 Vidas restantes");
        iniciar.setText("INICIAR");
    }


    public void abrirToast(String texto){
        Toast.makeText(
                getApplicationContext(),
                texto,
                Toast.LENGTH_LONG
        ).show();
    }

}